# -*- coding: utf-8 -*-
"""FDE 捏脸助手 —— 桌面客户端（AI 云端处理）

作者：ckjj
版本：1.0.0

说明：
    本软件只做两件事：把选中的图片**原样上传**到云端服务器，取回生成好的人物卡。
    所有 AI 计算都在服务器上完成，本机不需要显卡、也不需要装任何第三方库
    （只用 Python 自带的 tkinter + urllib）。
"""
import json
import os
import sys
import threading
import time
import urllib.error
import urllib.request
import tkinter as tk
from tkinter import filedialog

APP_NAME = "FDE 捏脸助手"
AUTHOR = "ckjj"
VERSION = "1.0.0"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE_DIR, "client_config.json")
OUTPUT_DIR = os.path.join(BASE_DIR, "output")

# ---------------------------------------------------------------------------
# 分发给远程用户时，把 server 改成你的公网地址、api_key 填上服务端的 FDE_API_KEY。
# 也可以不改代码：在同目录放一个 client_config.json，内容形如
#     {"server": "https://api.xinglan.space", "api_key": "你的密钥"}
# 客户端会优先读它。地址不在界面上显示，用户无感。
# ---------------------------------------------------------------------------
DEFAULT_SERVER = "http://127.0.0.1:8000"
DEFAULT_API_KEY = ""

# Cloudflare 的「浏览器完整性检查」会拦掉 Python 默认的 User-Agent（返回 403 / code 1010），
# 所以所有请求统一带一个带标识的浏览器风格 UA。
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) FDE-Client/1.0.0"
BASE_HEADERS = {"User-Agent": UA, "Accept": "*/*"}

# 配色
BG = "#14161a"
PANEL = "#191c22"
BORDER = "#2a3038"
FG = "#e6e8ec"
DIM = "#8b93a1"
ACCENT = "#2f6bff"

IMAGE_EXT = (".jpg", ".jpeg", ".png", ".bmp", ".webp")


# --------------------------------------------------------------------- 配置
def load_config():
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            cfg = json.load(f)
        return cfg if isinstance(cfg, dict) else {}
    except Exception:
        return {}


def save_config(cfg):
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


# --------------------------------------------------------------------- 网络
class CloudError(RuntimeError):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def request_card(server, file_path, timeout=300, retries=3, api_key="", token=""):
    """把图片原始字节上传到云端，返回 (人物卡字节, 上传字节数, 剩余次数)。"""
    name = os.path.basename(file_path)
    with open(file_path, "rb") as f:
        data = f.read()                       # 原样读取，不压缩
    url = server.rstrip("/") + "/v1/extract/card"
    last = None
    for attempt in range(retries):
        headers = {"Content-Type": "application/octet-stream",
                   "X-Filename": name,
                   "Content-Length": str(len(data))}
        headers.update(BASE_HEADERS)
        if api_key:
            headers["X-API-Key"] = api_key
        if token:
            headers["X-Auth-Token"] = token
        req = urllib.request.Request(url, data=data, method="POST", headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.read(), len(data), resp.headers.get("X-Remain")
        except urllib.error.HTTPError as exc:
            body = exc.read()
            try:
                detail = json.loads(body.decode("utf-8")).get("detail", "")
            except Exception:
                detail = body[:200].decode("utf-8", "replace")
            if exc.code == 503 and attempt < retries - 1:
                last = CloudError("云端繁忙，正在重试…", 503)
                time.sleep(1.0 + attempt)
                continue
            raise CloudError(detail or ("服务端返回 HTTP %d" % exc.code), exc.code) from None
        except urllib.error.URLError as exc:
            last = CloudError("无法连接云端服务器：%s" % exc.reason)
            if attempt < retries - 1:
                time.sleep(1.0 + attempt)
                continue
            raise last from None
    raise last or CloudError("上传失败")


# --------------------------------------------------------------------- 界面
class App(object):
    def __init__(self, root):
        self.root = root
        self.cfg = load_config()
        # 服务器地址与密钥都来自内置配置，界面上不显示
        self.server = (self.cfg.get("server") or DEFAULT_SERVER).strip()
        self.api_key = (self.cfg.get("api_key") or DEFAULT_API_KEY).strip()
        self.token = (self.cfg.get("token") or "").strip()
        self.identity = None            # /v1/me 返回的身份信息
        self.files = []
        self.busy = False
        self.preview = None
        self.last_out = None
        self.online = None
        self._probing = False

        root.title("%s  v%s" % (APP_NAME, VERSION))
        root.configure(bg=BG)
        root.geometry("560x680")
        root.minsize(520, 640)

        self._build()
        self._poll_server()

    # ---------------- 控件 ----------------
    def _build(self):
        pad = dict(padx=16)

        # 连接状态（不暴露服务器地址）
        row = tk.Frame(self.root, bg=BG)
        row.pack(fill="x", pady=(14, 2), **pad)
        self.dot = tk.Label(row, text="●", bg=BG, fg="#5f6875",
                            font=("Microsoft YaHei", 11))
        self.dot.pack(side="left")
        self.conn = tk.Label(row, text="正在连接云端 AI…", bg=BG, fg=DIM,
                             font=("Microsoft YaHei", 9))
        self.conn.pack(side="left", padx=(6, 0))
        # 重新连接：手动立刻探活一次，不用干等自动轮询
        self.btn_reconnect = tk.Button(row, text="重新连接", command=self.on_reconnect,
                                       relief="flat", bd=0, bg="#1f242c", fg="#8b93a1",
                                       activebackground="#2f3742", activeforeground="#ffffff",
                                       font=("Microsoft YaHei", 8), padx=8, pady=3,
                                       cursor="hand2", disabledforeground="#4a5361")
        self.btn_reconnect.pack(side="left", padx=(8, 0))
        self.btn_auth = tk.Button(row, text="登录 / 注册", command=self.on_auth,
                                  relief="flat", bd=0, bg="#252b34", fg="#c8ced9",
                                  activebackground="#2f3742", activeforeground="#fff",
                                  font=("Microsoft YaHei", 9), padx=12, pady=4,
                                  cursor="hand2")
        self.btn_auth.pack(side="right")

        self.quota_label = tk.Label(self.root, text="", bg=BG, fg="#9aa3b2",
                                    font=("Microsoft YaHei", 9), anchor="w")
        self.quota_label.pack(fill="x", pady=(0, 8), **pad)

        # 按钮行
        row = tk.Frame(self.root, bg=BG)
        row.pack(fill="x", pady=(6, 4), **pad)
        self.btn_open = self._button(row, "选择图片", self.on_open)
        self.btn_open.pack(side="left")
        self.btn_go = self._button(row, "开始生成", self.on_start, primary=True)
        self.btn_go.pack(side="left", padx=8)
        self.btn_go.config(state="disabled")
        self.btn_dir = self._button(row, "打开文件夹", self.on_open_dir)
        self.btn_dir.pack(side="left")
        self.btn_dir.config(state="disabled")

        self.file_label = tk.Label(self.root, text="未选择图片", bg=BG, fg=DIM,
                                   font=("Microsoft YaHei", 9), anchor="w")
        self.file_label.pack(fill="x", pady=(2, 8), **pad)

        # 预览
        wrap = tk.Frame(self.root, bg=BORDER)
        wrap.pack(pady=2)
        self.canvas = tk.Label(wrap, bg="#0b0d10", width=224, height=313,
                               text="预览", fg="#3a4250",
                               font=("Microsoft YaHei", 11))
        self.canvas.pack(padx=1, pady=1)

        # 状态
        self.status = tk.Label(self.root, text="就绪", bg=BG, fg=DIM,
                               font=("Microsoft YaHei", 9), anchor="w",
                               wraplength=520, justify="left")
        self.status.pack(fill="x", pady=(12, 2), **pad)

        self.path_label = tk.Label(self.root, text="", bg=BG, fg="#5f6875",
                                   font=("Microsoft YaHei", 8), anchor="w",
                                   wraplength=520, justify="left")
        self.path_label.pack(fill="x", **pad)

        # 底部
        tk.Frame(self.root, bg=BORDER, height=1).pack(fill="x", side="bottom", pady=(0, 0))
        tk.Label(self.root, text="作者：%s　　版本：%s" % (AUTHOR, VERSION),
                 bg=PANEL, fg=DIM, font=("Microsoft YaHei", 9), pady=7).pack(
            fill="x", side="bottom")

    def _button(self, parent, text, cmd, primary=False):
        return tk.Button(parent, text=text, command=cmd, relief="flat", bd=0,
                         bg=ACCENT if primary else "#252b34",
                         fg="#ffffff" if primary else "#c8ced9",
                         activebackground="#1e4fd0" if primary else "#2f3742",
                         activeforeground="#ffffff",
                         font=("Microsoft YaHei", 9), padx=14, pady=7,
                         cursor="hand2", disabledforeground="#5b6472")

    # ---------------- 事件 ----------------
    def on_open(self):
        paths = filedialog.askopenfilenames(
            title="选择图片",
            filetypes=[("图片", "*.jpg *.jpeg *.png *.bmp *.webp"), ("所有文件", "*.*")])
        if not paths:
            return
        self.files = [p for p in paths if p.lower().endswith(IMAGE_EXT)] or list(paths)
        if len(self.files) == 1:
            self.file_label.config(text=os.path.basename(self.files[0]), fg=FG)
        else:
            self.file_label.config(text="已选择 %d 张图片" % len(self.files), fg=FG)
        self._refresh_buttons()
        self.set_status("已选择 %d 张，点击「开始生成」" % len(self.files))

    def on_start(self):
        if self.busy or not self.files:
            return
        self.busy = True
        self.btn_go.config(state="disabled")
        self.btn_open.config(state="disabled")
        threading.Thread(target=self._work, args=(self.server, list(self.files)),
                         daemon=True).start()

    def on_open_dir(self):
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        if sys.platform.startswith("win"):
            os.startfile(OUTPUT_DIR)                       # noqa: S606
        else:
            import subprocess
            subprocess.Popen(["xdg-open", OUTPUT_DIR])

    # ---------------- 后台任务 ----------------
    def _work(self, server, files):
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        ok = 0
        for i, path in enumerate(files):
            name = os.path.basename(path)
            self.ui(self.set_status, "云端 AI 处理中…（%d/%d）%s" % (i + 1, len(files), name))
            t0 = time.perf_counter()
            try:
                card, sent, remain = request_card(server, path, api_key=self.api_key,
                                                  token=self.token)
            except CloudError as exc:
                self.ui(self.set_status, "失败：%s" % exc)
                continue
            except Exception as exc:                        # pragma: no cover
                self.ui(self.set_status, "失败：%s" % exc)
                continue
            stem = os.path.splitext(name)[0]
            out = os.path.join(OUTPUT_DIR, stem + "_character.png")
            try:
                with open(out, "wb") as f:
                    f.write(card)
            except OSError as exc:
                self.ui(self.set_status, "无法写入文件：%s" % exc)
                continue
            ok += 1
            ms = (time.perf_counter() - t0) * 1000
            self.last_out = out
            self.ui(self._show_result, out, sent, len(card), ms, i + 1, len(files), name, remain)
        self.ui(self._done, ok, len(files))

    def _show_result(self, out, sent, size, ms, idx, total, name, remain=None):
        try:
            img = tk.PhotoImage(file=out)
            self.preview = img
            self.canvas.config(image=img, text="", width=img.width(), height=img.height())
        except Exception:
            pass
        extra = ""
        if remain not in (None, ""):
            extra = "　剩余 %s 次" % remain
        self.set_status("完成 %s　上传 %d KB　卡片 %d KB　用时 %.1f 秒%s"
                        % (name, sent // 1024, size // 1024, ms / 1000.0, extra))
        self.path_label.config(text=out)
        if remain not in (None, ""):
            self._refresh_quota()

    def _done(self, ok, total):
        self.busy = False
        self.btn_open.config(state="normal")
        self.btn_dir.config(state="normal")
        self._refresh_buttons()
        if ok:
            self.set_status("全部完成：成功 %d / %d，人物卡已保存到 output 文件夹" % (ok, total))
        else:
            self.set_status("没有生成成功，请检查网络或稍后再试")

    # ---------------- 小工具 ----------------
    def on_reconnect(self):
        """手动重新连接：立刻探活一次（不用等 30 秒的自动轮询）。"""
        self.online = None
        self.dot.config(fg="#e0b64d")
        self.conn.config(text="正在重新连接…", fg=DIM)
        self.btn_reconnect.config(state="disabled", text="连接中")
        self._refresh_buttons()

        def done(ok):
            self.btn_reconnect.config(state="normal", text="重新连接")
        self._probe_now(done)

    def _probe_now(self, on_done=None):
        """在后台探活一次，回来后更新状态灯与额度。

        云端隧道首次响应可能要十几秒，所以超时给到 25 秒。
        """
        def check():
            ok = False
            try:
                req = urllib.request.Request(self.server.rstrip("/") + "/v1/health",
                                             headers=dict(BASE_HEADERS))
                with urllib.request.urlopen(req, timeout=25) as r:
                    ok = json.loads(r.read().decode("utf-8")).get("status") == "ok"
            except Exception:
                ok = False
            try:
                if self.root.winfo_exists():
                    self.ui(self._set_online, ok)
                    if ok:
                        self._refresh_quota()
                    if on_done is not None:
                        self.ui(on_done, ok)
            except Exception:
                pass
        threading.Thread(target=check, daemon=True).start()

    def _probe_done(self, ok):
        self._probing = False

    def _poll_server(self):
        """每 30 秒自动探活一次；上一轮没返回就跳过这一轮。"""
        if not self._probing:
            self._probing = True
            self._probe_now(self._probe_done)
        try:
            self.root.after(30000, self._poll_server)
        except Exception:
            pass

    def _set_online(self, ok):
        self.online = ok
        if ok:
            self.dot.config(fg="#3ddc84")
            self.conn.config(text="已连接云端 AI", fg=FG)
        else:
            self.dot.config(fg="#ff5c5c")
            self.conn.config(text="未连接到云端服务（仍可尝试生成）", fg="#ff8a8a")
        self._refresh_buttons()

    def _refresh_buttons(self):
        # 连接状态未知（None）时也允许点——用户不用干等探活结果；
        # 只有明确探测失败（False）才禁用。
        can = bool(self.files) and not self.busy and self.online is not False
        ident = self.identity or {}
        if ident.get("kind") == "guest" and ident.get("blocked"):
            can = False                      # 访客额度用完，先登录
        self.btn_go.config(state="normal" if can else "disabled")

    # ---------------- 身份与额度 ----------------
    def on_auth(self):
        if self.token:                       # 已登录 -> 退出
            self.token = ""
            self.cfg.pop("token", None)
            save_config(self.cfg)
            self.identity = None
            self.set_status("已退出登录，回到访客模式")
            self._refresh_quota()
            return
        AuthDialog(self.root, self.server, self._on_auth_ok)

    def _on_auth_ok(self, token, username):
        self.token = token
        self.cfg["token"] = token
        save_config(self.cfg)
        self.set_status("已登录：%s" % username)
        self._refresh_quota()

    def _refresh_quota(self):
        """拉 /v1/me，更新身份与剩余次数。"""
        def work():
            try:
                req = urllib.request.Request(self.server.rstrip("/") + "/v1/me",
                                             headers=dict(BASE_HEADERS))
                if self.token:
                    req.add_header("X-Auth-Token", self.token)
                with urllib.request.urlopen(req, timeout=25) as r:
                    me = json.loads(r.read().decode("utf-8"))
            except Exception:
                me = None
            try:
                if self.root.winfo_exists():
                    self.ui(self._apply_quota, me)
            except Exception:
                pass
        threading.Thread(target=work, daemon=True).start()

    def _apply_quota(self, me):
        self.identity = me
        if not me:
            self.quota_label.config(text="")
            self.btn_auth.config(text="登录 / 注册")
            self._refresh_buttons()
            return
        kind = me.get("kind")
        if kind == "user":
            self.quota_label.config(
                text="已登录：%s　　今日剩余 %s / %s 次"
                     % (me.get("username"), me.get("remain_today"), me.get("daily_quota")),
                fg="#7fd39b")
            self.btn_auth.config(text="退出登录")
        elif kind == "admin":
            self.quota_label.config(text="管理员模式（不限次数）", fg="#e0b64d")
            self.btn_auth.config(text="登录 / 注册")
        else:
            quota = me.get("guest_quota", 3)
            if me.get("blocked"):
                self.quota_label.config(
                    text="访客试用 %s 次已用完 —— 点右上角「登录 / 注册」，之后每天 6 次" % quota,
                    fg="#ff8a8a")
            else:
                self.quota_label.config(
                    text="访客试用：剩余 %s 次（共 %s 次）　登录后每天 6 次"
                         % (me.get("remain_today"), quota), fg="#9aa3b2")
            self.btn_auth.config(text="登录 / 注册")
        self._refresh_buttons()

    def set_status(self, text):
        self.status.config(text=text)

    def ui(self, fn, *args):
        self.root.after(0, lambda: fn(*args))


class AuthDialog(object):
    """登录 / 注册对话框。"""

    def __init__(self, parent, server, on_success):
        self.server = (server or "").rstrip("/")
        self.on_success = on_success

        win = tk.Toplevel(parent)
        self.win = win
        win.title("登录 / 注册")
        win.configure(bg=BG)
        win.resizable(False, False)
        win.transient(parent)
        try:
            parent.update_idletasks()
            x = parent.winfo_rootx() + (parent.winfo_width() - 360) // 2
            y = parent.winfo_rooty() + 110
            win.geometry("360x310+%d+%d" % (max(0, x), max(0, y)))
        except Exception:
            win.geometry("360x310")
        try:
            win.grab_set()
        except Exception:
            pass

        tk.Label(win, text="登录后每天可用 6 次", bg=BG, fg=FG,
                 font=("Microsoft YaHei", 11, "bold")).pack(pady=(22, 4))
        tk.Label(win, text="不登录则按访客计，累计 3 次", bg=BG, fg=DIM,
                 font=("Microsoft YaHei", 9)).pack()

        body = tk.Frame(win, bg=BG)
        body.pack(pady=16, padx=26, fill="x")
        tk.Label(body, text="用户名", bg=BG, fg=DIM,
                 font=("Microsoft YaHei", 9)).grid(row=0, column=0, sticky="w", pady=4)
        self.user = tk.Entry(body, bg=PANEL, fg=FG, relief="flat", insertbackground=FG,
                             font=("Consolas", 10), highlightthickness=1,
                             highlightbackground=BORDER, highlightcolor=ACCENT)
        self.user.grid(row=0, column=1, sticky="ew", pady=4, padx=(8, 0))
        tk.Label(body, text="密码", bg=BG, fg=DIM,
                 font=("Microsoft YaHei", 9)).grid(row=1, column=0, sticky="w", pady=4)
        self.pwd = tk.Entry(body, show="●", bg=PANEL, fg=FG, relief="flat",
                            insertbackground=FG, font=("Consolas", 10),
                            highlightthickness=1, highlightbackground=BORDER,
                            highlightcolor=ACCENT)
        self.pwd.grid(row=1, column=1, sticky="ew", pady=4, padx=(8, 0))
        body.columnconfigure(1, weight=1)

        row = tk.Frame(win, bg=BG)
        row.pack()
        self.btn_login = tk.Button(row, text="登录", command=lambda: self.submit("login"),
                                   relief="flat", bd=0, bg=ACCENT, fg="#ffffff",
                                   activebackground="#1e4fd0", activeforeground="#ffffff",
                                   font=("Microsoft YaHei", 10), padx=22, pady=6,
                                   cursor="hand2")
        self.btn_login.pack(side="left", padx=(0, 10))
        self.btn_reg = tk.Button(row, text="注册新账号", command=lambda: self.submit("register"),
                                 relief="flat", bd=0, bg="#252b34", fg="#c8ced9",
                                 activebackground="#2f3742", activeforeground="#ffffff",
                                 font=("Microsoft YaHei", 10), padx=22, pady=6,
                                 cursor="hand2")
        self.btn_reg.pack(side="left")

        self.tip = tk.Label(win, text="", bg=BG, fg="#ff8a8a",
                            font=("Microsoft YaHei", 9), wraplength=310, justify="left")
        self.tip.pack(pady=(8, 0))
        self.pwd.bind("<Return>", lambda e: self.submit("login"))
        self.user.focus_set()

    def _post(self, path, payload):
        headers = {"Content-Type": "application/json"}
        headers.update(BASE_HEADERS)
        req = urllib.request.Request(self.server + path, method="POST",
                                     data=json.dumps(payload).encode("utf-8"),
                                     headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                return json.loads(r.read().decode("utf-8")), None
        except urllib.error.HTTPError as e:
            try:
                return None, json.loads(e.read().decode("utf-8")).get("detail", "失败")
            except Exception:
                return None, "HTTP %s" % e.code
        except Exception as e:
            return None, "无法连接服务器：%s" % e

    def submit(self, mode):
        username = self.user.get().strip()
        password = self.pwd.get()
        if not username or not password:
            self.tip.config(text="请填写用户名和密码", fg="#ff8a8a")
            return
        self.btn_login.config(state="disabled")
        self.btn_reg.config(state="disabled")
        self.tip.config(text="处理中…", fg=DIM)

        def work():
            data, err = self._post("/v1/login" if mode == "login" else "/v1/register",
                                   {"username": username, "password": password})
            try:
                self.win.after(0, lambda: self._done(data, err, username))
            except Exception:
                pass
        threading.Thread(target=work, daemon=True).start()

    def _done(self, data, err, username):
        if err or not data:
            self.tip.config(text=err or "失败", fg="#ff8a8a")
            self.btn_login.config(state="normal")
            self.btn_reg.config(state="normal")
            return
        self.on_success(data["token"], data.get("username", username))
        try:
            self.win.destroy()
        except Exception:
            pass


def main(root=None):
    """root 为 None 时自己建窗口；由启动器传入时复用它已有的窗口。"""
    if sys.platform.startswith("win"):
        try:                                                # 高分屏清晰
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    own = root is None
    if own:
        root = tk.Tk()
    App(root)
    if not own:
        return 0
    if "--selftest" in sys.argv:                            # 供自动化检查界面能否构建
        root.after(400, root.destroy)
        root.mainloop()
        print("SELFTEST OK: 界面构建成功，作者=%s 版本=%s 文件=%s"
              % (AUTHOR, VERSION, os.path.basename(__file__)))
        return 0
    root.mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
