# -*- coding: utf-8 -*-
"""FDE 捏脸助手 —— 桌面客户端（AI 云端处理）

作者：ckjj
版本：1.2.0

说明：
    本软件只做两件事：把选中的图片**原样上传**到云端服务器，取回生成好的人物卡。
    所有 AI 计算都在服务器上完成，本机不需要显卡、也不需要装任何第三方库。

启动方式：**双击「启动.bat」**。
    （直接双击本 .py 也能用：会自动切到随包的 python\\ 重新启动。）
"""
import json
import os
import re
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import tkinter as tk
from tkinter import filedialog, messagebox

APP_NAME = "FDE 捏脸助手"
AUTHOR = "ckjj"
VERSION = "1.2.0"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE_DIR, "client_config.json")
OUTPUT_DIR = os.path.join(BASE_DIR, "output")

CREATE_NO_WINDOW = 0x08000000


def _ensure_bundled_python():
    """双击 .py 时，Windows 可能用系统 Python 打开（那个环境可能没 tkinter/依赖）。

    只要本目录下有随包的 python\\，就改用它重新启动自己，保证双击也能用。
    返回 True 表示"已经交给随包 Python 了，本进程应当退出"。
    """
    if os.environ.get("FDE_RELAUNCHED"):
        return False
    exe = os.path.join(BASE_DIR, "python", "pythonw.exe")
    if not os.path.exists(exe):
        exe = os.path.join(BASE_DIR, "python", "python.exe")
    if not os.path.exists(exe):
        return False                       # 没有随包 Python，就用当前解释器
    try:
        cur = os.path.normcase(os.path.abspath(sys.executable))
        pydir = os.path.normcase(os.path.abspath(os.path.join(BASE_DIR, "python")))
        if os.path.dirname(cur) == pydir:
            return False                   # 已经跑在随包 Python 上（python.exe/pythonw.exe 都算）
    except Exception:
        return False
    try:
        import subprocess
        env = dict(os.environ)
        env["FDE_RELAUNCHED"] = "1"
        flags = CREATE_NO_WINDOW if os.name == "nt" else 0
        subprocess.Popen([exe, os.path.abspath(__file__)] + sys.argv[1:],
                         cwd=BASE_DIR, env=env, creationflags=flags,
                         close_fds=True)
        return True
    except Exception:
        return False

# ---------------------------------------------------------------------------
# 分发给远程用户时，把 server 改成你的公网地址、api_key 填上服务端的 FDE_API_KEY。
# 也可以不改代码：在同目录放一个 client_config.json，内容形如
#     {"server": "https://api.xinglan.space", "api_key": "你的密钥"}
# 客户端会优先读它。地址不在界面上显示，用户无感。
# 注意：DEFAULT_SERVER 现在在下面「配置」一节里定义（那里带自愈逻辑）。
# ---------------------------------------------------------------------------
DEFAULT_API_KEY = ""

# Cloudflare 的「浏览器完整性检查」会拦掉 Python 默认的 User-Agent（返回 403 / code 1010），
# 所以所有请求统一带一个带标识的浏览器风格 UA。
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) FDE-Client/1.1.0"
BASE_HEADERS = {"User-Agent": UA, "Accept": "*/*"}

# 配色
BG = "#14161a"
PANEL = "#191c22"
BORDER = "#2a3038"
FG = "#e6e8ec"
DIM = "#8b93a1"
ACCENT = "#2f6bff"

IMAGE_EXT = (".jpg", ".jpeg", ".png", ".bmp", ".webp")

# 预览框尺寸（选图后立刻显示在这里；生成完成后显示人物卡）
PREVIEW_W, PREVIEW_H = 300, 300


# --------------------------------------------------------------------- 配置
# 默认连云端。写成模块常量是为了「配置文件丢失/被覆盖」时也能自动恢复，
# 用户不需要手动填服务器地址。
DEFAULT_SERVER = "https://api.xinglan.space"
LOCAL_SERVERS = ("http://127.0.0.1:8000", "http://127.0.0.1:8001",
                 "http://localhost:8000")


def load_config():
    try:
        # utf-8-sig：兼容记事本等编辑器写入的 BOM，否则 json 解析会失败
        with open(CONFIG_PATH, encoding="utf-8-sig") as f:
            cfg = json.load(f)
        cfg = cfg if isinstance(cfg, dict) else {}
    except Exception:
        cfg = {}
    # 自愈：配置为空 -> 回云端；配置指向本机但本机服务没在跑 -> 也回云端
    # （本机服务确实在跑时保留本机地址，方便自己测试）
    srv = (cfg.get("server") or "").strip()
    if not srv:
        cfg["server"] = DEFAULT_SERVER
        save_config(cfg)
    elif _is_local_url(srv) and not _local_alive(srv):
        cfg["server"] = DEFAULT_SERVER
        save_config(cfg)
    return cfg


def save_config(cfg):
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


# --------------------------------------------------------------------- 预览
def load_preview(path, max_w=PREVIEW_W, max_h=PREVIEW_H):
    """把图片读成 (PhotoImage, w, h)，等比缩放进 max_w×max_h。

    PNG/GIF/BMP 用 tkinter 原生；JPEG 等走 Pillow（便携版已内置）。
    都失败返回 None，界面只显示文件名，不影响生成。
    """
    try:
        from PIL import Image, ImageTk
        im = Image.open(path)
        im = im.convert("RGB")
        im.thumbnail((max_w, max_h), Image.LANCZOS)
        return ImageTk.PhotoImage(im), im.width, im.height
    except Exception:
        pass
    try:
        img = tk.PhotoImage(file=path)
        k = max(img.width() // max_w, img.height() // max_h)
        if img.width() % max_w:
            k += 1
        if k > 1:
            img = img.subsample(k, k)
        return img, img.width(), img.height()
    except Exception:
        return None


def _port_open(host, port, timeout=0.35):
    """本机端口是否有人在监听（用于判断配置里的本机地址还要不要用）。"""
    import socket
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except Exception:
        return False


def _is_local_url(url):
    try:
        u = urllib.parse.urlsplit(url if "//" in url else "http://" + url)
    except Exception:
        return False
    return (u.hostname or "") in ("127.0.0.1", "localhost", "0.0.0.0")


def _local_alive(url):
    """配置指向本机时，本机服务是否真的在跑（在跑就保留本机地址）。"""
    try:
        u = urllib.parse.urlsplit(url if "//" in url else "http://" + url)
    except Exception:
        return False
    host = u.hostname or "127.0.0.1"
    if host == "0.0.0.0":
        host = "127.0.0.1"
    return _port_open(host, u.port or 80)


# --------------------------------------------------------------------- 网络
class CloudError(RuntimeError):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def request_card(server, file_path, timeout=600, retries=3, api_key="", token="",
                 mode="fast"):
    """把图片原始字节上传到云端，返回 (人物卡字节, 上传字节数, 剩余次数)。

    mode='qwen' 时服务端会用本地视觉模型校正肤色（更慢）。
    """
    name = os.path.basename(file_path)
    with open(file_path, "rb") as f:
        data = f.read()                       # 原样读取，不压缩
    url = server.rstrip("/") + "/v1/extract/card"
    last = None
    for attempt in range(retries):
        headers = {"Content-Type": "application/octet-stream",
                   "X-Filename": name,
                   "Content-Length": str(len(data))}
        headers.update(BASE_HEADERS)
        if api_key:
            headers["X-API-Key"] = api_key
        if token:
            headers["X-Auth-Token"] = token
        if mode == "qwen":
            headers["X-Mode"] = "qwen"
        req = urllib.request.Request(url, data=data, method="POST", headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.read(), len(data), resp.headers.get("X-Remain")
        except urllib.error.HTTPError as exc:
            body = exc.read()
            try:
                detail = json.loads(body.decode("utf-8")).get("detail", "")
            except Exception:
                detail = body[:200].decode("utf-8", "replace")
            if exc.code == 503 and attempt < retries - 1:
                last = CloudError("云端繁忙，正在重试…", 503)
                time.sleep(1.0 + attempt)
                continue
            raise CloudError(detail or ("服务端返回 HTTP %d" % exc.code), exc.code) from None
        except urllib.error.URLError as exc:
            last = CloudError("无法连接云端服务器：%s" % exc.reason)
            if attempt < retries - 1:
                time.sleep(1.0 + attempt)
                continue
            raise last from None
    raise last or CloudError("上传失败")


# --------------------------------------------------------------------- 界面
class App(object):
    def __init__(self, root):
        self.root = root
        self.cfg = load_config()
        # 服务器地址与密钥都来自内置配置，界面上不显示
        self.server = (self.cfg.get("server") or DEFAULT_SERVER).strip()
        self.api_key = (self.cfg.get("api_key") or DEFAULT_API_KEY).strip()
        self.token = (self.cfg.get("token") or "").strip()
        self.identity = None            # /v1/me 返回的身份信息
        self.files = []
        self.busy = False
        self.preview = None
        self.last_out = None
        self.online = None
        self._probing = False
        self._prog_run = False
        self._prog_mode = "ind"
        self._prog_pos = 0.0
        self._prog_dir = 1
        self._prog_frac = 0.0
        self.update_info = None
        self.quotas = {"guest": 10, "user": 30, "guest_qwen": 1, "user_qwen": 5}
        self.cur_index = 0              # 当前预览的是第几张
        self.preview_img = None

        root.title("%s  v%s" % (APP_NAME, VERSION))
        root.configure(bg=BG)
        root.geometry("580x780")
        root.minsize(540, 720)

        self._build()
        self._poll_server()

    # ---------------- 控件 ----------------
    def _build(self):
        pad = dict(padx=16)

        # 连接状态（不暴露服务器地址）
        row = tk.Frame(self.root, bg=BG)
        row.pack(fill="x", pady=(14, 2), **pad)
        self.dot = tk.Label(row, text="●", bg=BG, fg="#5f6875",
                            font=("Microsoft YaHei", 11))
        self.dot.pack(side="left")
        self.conn = tk.Label(row, text="正在连接云端 AI…", bg=BG, fg=DIM,
                             font=("Microsoft YaHei", 9))
        self.conn.pack(side="left", padx=(6, 0))
        # 重新连接：手动立刻探活一次，不用干等自动轮询
        self.btn_reconnect = tk.Button(row, text="重新连接", command=self.on_reconnect,
                                       relief="flat", bd=0, bg="#1f242c", fg="#8b93a1",
                                       activebackground="#2f3742", activeforeground="#ffffff",
                                       font=("Microsoft YaHei", 8), padx=8, pady=3,
                                       cursor="hand2", disabledforeground="#4a5361")
        self.btn_reconnect.pack(side="left", padx=(8, 0))
        # 检查更新：手动查一次版本，有新版本会弹出更新内容
        self.btn_check = tk.Button(row, text="检查更新", command=self.on_check_update,
                                   relief="flat", bd=0, bg="#1f242c", fg="#8b93a1",
                                   activebackground="#2f3742", activeforeground="#ffffff",
                                   font=("Microsoft YaHei", 8), padx=8, pady=3,
                                   cursor="hand2", disabledforeground="#4a5361")
        self.btn_check.pack(side="left", padx=(6, 0))
        self.btn_auth = tk.Button(row, text="登录 / 注册", command=self.on_auth,
                                  relief="flat", bd=0, bg="#252b34", fg="#c8ced9",
                                  activebackground="#2f3742", activeforeground="#fff",
                                  font=("Microsoft YaHei", 9), padx=12, pady=4,
                                  cursor="hand2")
        self.btn_auth.pack(side="right")

        self.quota_label = tk.Label(self.root, text="", bg=BG, fg="#9aa3b2",
                                    font=("Microsoft YaHei", 9), anchor="w")
        self.quota_label.pack(fill="x", pady=(0, 8), **pad)

        # 精细模式（用本地 Qwen 校正肤色）+ 进度条
        opt = tk.Frame(self.root, bg=BG)
        opt.pack(fill="x", pady=(0, 2), **pad)
        self.qwen_var = tk.BooleanVar(value=False)
        self.chk_qwen = tk.Checkbutton(
            opt, text="精细模式（AI 校正肤色，较慢）", variable=self.qwen_var,
            command=self._on_mode_change, bg=BG, fg="#9aa3b2",
            activebackground=BG, activeforeground=FG, selectcolor=PANEL,
            font=("Microsoft YaHei", 9), bd=0, highlightthickness=0,
            cursor="hand2")
        self.chk_qwen.pack(side="left")

        self.pbar_bg = tk.Frame(self.root, bg="#1f242c", height=6)
        self.pbar_bg.pack(fill="x", padx=16, pady=(6, 2))
        self.pbar_bg.pack_propagate(False)
        self.pbar = tk.Frame(self.pbar_bg, bg=ACCENT, height=6)
        self.pbar.place(x=0, y=0, relheight=1, relwidth=0)

        # 按钮行
        row = tk.Frame(self.root, bg=BG)
        row.pack(fill="x", pady=(6, 4), **pad)
        self.btn_open = self._button(row, "选择图片", self.on_open)
        self.btn_open.pack(side="left")
        self.btn_go = self._button(row, "开始生成", self.on_start, primary=True)
        self.btn_go.pack(side="left", padx=8)
        self.btn_go.config(state="disabled")
        self.btn_dir = self._button(row, "打开文件夹", self.on_open_dir)
        self.btn_dir.pack(side="left")
        self.btn_dir.config(state="disabled")

        self.file_label = tk.Label(self.root, text="未选择图片", bg=BG, fg=DIM,
                                   font=("Microsoft YaHei", 9), anchor="w")
        self.file_label.pack(fill="x", pady=(2, 4), **pad)

        # 预览：选图后立刻显示所选图片；生成完成后显示人物卡
        wrap = tk.Frame(self.root, bg=BORDER)
        wrap.pack(pady=2)
        self.canvas = tk.Label(wrap, bg="#0b0d10", width=1, height=1,
                               text="预览", fg="#3a4250",
                               font=("Microsoft YaHei", 11), cursor="hand2")
        self.canvas.pack(padx=1, pady=1)
        self.canvas.bind("<Button-1>", lambda e: self._cycle_preview())
        self.canvas.config(width=PREVIEW_W, height=PREVIEW_H)

        self.hint = tk.Label(self.root, text="", bg=BG, fg="#5f6875",
                             font=("Microsoft YaHei", 8))
        self.hint.pack(fill="x", pady=(2, 4))

        # 状态
        self.status = tk.Label(self.root, text="就绪", bg=BG, fg=DIM,
                               font=("Microsoft YaHei", 9), anchor="w",
                               wraplength=520, justify="left")
        self.status.pack(fill="x", pady=(12, 2), **pad)

        self.path_label = tk.Label(self.root, text="", bg=BG, fg="#5f6875",
                                   font=("Microsoft YaHei", 8), anchor="w",
                                   wraplength=520, justify="left")
        self.path_label.pack(fill="x", **pad)

        # 底部
        tk.Frame(self.root, bg=BORDER, height=1).pack(fill="x", side="bottom", pady=(0, 0))
        tk.Label(self.root, text="作者：%s　　版本：%s" % (AUTHOR, VERSION),
                 bg=PANEL, fg=DIM, font=("Microsoft YaHei", 9), pady=7).pack(
            fill="x", side="bottom")

    def _button(self, parent, text, cmd, primary=False):
        return tk.Button(parent, text=text, command=cmd, relief="flat", bd=0,
                         bg=ACCENT if primary else "#252b34",
                         fg="#ffffff" if primary else "#c8ced9",
                         activebackground="#1e4fd0" if primary else "#2f3742",
                         activeforeground="#ffffff",
                         font=("Microsoft YaHei", 9), padx=14, pady=7,
                         cursor="hand2", disabledforeground="#5b6472")

    # ---------------- 事件 ----------------
    def on_open(self):
        paths = filedialog.askopenfilenames(
            title="选择图片",
            filetypes=[("图片", "*.jpg *.jpeg *.png *.bmp *.webp"), ("所有文件", "*.*")])
        if not paths:
            return
        self.files = [p for p in paths if p.lower().endswith(IMAGE_EXT)] or list(paths)
        self.cur_index = 0
        # 选完立刻把图片显示在下面；换一张就换一张
        self._preview_file(0)
        self._refresh_buttons()
        self.set_status("已选择 %d 张，点击「开始生成」" % len(self.files))

    def _preview_file(self, idx):
        """在预览框里显示第 idx 张所选图片（选图后立即调用）。"""
        if not self.files:
            return
        idx = max(0, min(idx, len(self.files) - 1))
        self.cur_index = idx
        path = self.files[idx]
        name = os.path.basename(path)
        got = load_preview(path)
        if got is None:
            self.preview_img = None
            self.canvas.config(image="", text="无法预览\n%s" % name[:28],
                               fg="#ff8a8a", width=PREVIEW_W // 8,
                               height=PREVIEW_H // 16)
        else:
            img, w, h = got
            self.preview_img = img
            self.canvas.config(image=img, text="", width=w, height=h)
        if len(self.files) == 1:
            self.file_label.config(text=name, fg=FG)
            self.hint.config(text="")
        else:
            self.file_label.config(
                text="%s　（第 %d/%d 张）" % (name, idx + 1, len(self.files)), fg=FG)
            self.hint.config(text="点图片可切换到下一张（共 %d 张）" % len(self.files))

    def _cycle_preview(self):
        """点预览图在多张之间循环切换。"""
        if len(self.files) > 1:
            self._preview_file((self.cur_index + 1) % len(self.files))

    def on_start(self):
        if self.busy or not self.files:
            return
        self.busy = True
        self.btn_go.config(state="disabled")
        self.btn_open.config(state="disabled")
        threading.Thread(target=self._work, args=(self.server, list(self.files)),
                         daemon=True).start()

    def on_open_dir(self):
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        if sys.platform.startswith("win"):
            os.startfile(OUTPUT_DIR)                       # noqa: S606
        else:
            import subprocess
            subprocess.Popen(["xdg-open", OUTPUT_DIR])

    # ---------------- 后台任务 ----------------
    def _work(self, server, files):
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        ok = 0
        mode = self.current_mode()
        total = len(files)
        self.ui(self._progress_set, 0.0)
        for i, path in enumerate(files):
            name = os.path.basename(path)
            # 多张时按张数走进度；单张时用来回动画（等待时间不确定）
            if total > 1:
                self.ui(self._progress_show, True)
                self.ui(self._progress_set, i / float(total))
            else:
                self.ui(self._progress_show, False)
            tip = "精细模式处理中（AI 校正肤色，较慢）" if mode == "qwen" else "云端 AI 处理中"
            self.ui(self.set_status, "%s…（%d/%d）%s" % (tip, i + 1, total, name))
            t0 = time.perf_counter()
            try:
                card, sent, remain = request_card(server, path, api_key=self.api_key,
                                                  token=self.token, mode=mode)
            except CloudError as exc:
                self.ui(self.set_status, "失败：%s" % exc)
                continue
            except Exception as exc:                        # pragma: no cover
                self.ui(self.set_status, "失败：%s" % exc)
                continue
            stem = os.path.splitext(name)[0]
            out = os.path.join(OUTPUT_DIR, stem + "_character.png")
            try:
                with open(out, "wb") as f:
                    f.write(card)
            except OSError as exc:
                self.ui(self.set_status, "无法写入文件：%s" % exc)
                continue
            ok += 1
            ms = (time.perf_counter() - t0) * 1000
            self.last_out = out
            if total > 1:
                self.ui(self._progress_set, (i + 1) / float(total))
            self.ui(self._show_result, out, sent, len(card), ms, i + 1, total, name, remain)
        self.ui(self._progress_hide)
        self.ui(self._done, ok, total)

    def _show_result(self, out, sent, size, ms, idx, total, name, remain=None):
        try:
            img = tk.PhotoImage(file=out)
            self.preview = img
            self.canvas.config(image=img, text="", width=img.width(), height=img.height())
        except Exception:
            pass
        extra = ""
        if remain not in (None, ""):
            extra = "　剩余 %s 次" % remain
        self.set_status("完成 %s　上传 %d KB　卡片 %d KB　用时 %.1f 秒%s"
                        % (name, sent // 1024, size // 1024, ms / 1000.0, extra))
        self.path_label.config(text=out)
        if remain not in (None, ""):
            self._refresh_quota()

    def _done(self, ok, total):
        self.busy = False
        self.btn_open.config(state="normal")
        self.btn_dir.config(state="normal")
        self._refresh_buttons()
        if ok:
            self.set_status("全部完成：成功 %d / %d，人物卡已保存到 output 文件夹" % (ok, total))
        else:
            self.set_status("没有生成成功，请检查网络或稍后再试")

    # ---------------- 进度条 ----------------
    def _progress_show(self, determinate=False):
        """显示进度条；不确定模式跑来回动画（等待上传/推理的时间本来就不确定）。"""
        self._prog_mode = "det" if determinate else "ind"
        self._prog_pos = 0.0
        self._prog_dir = 1
        self._prog_frac = 0.0
        if not getattr(self, "_prog_run", False):
            self._prog_run = True
            self._animate()

    def _progress_set(self, frac):
        self._prog_mode = "det"
        self._prog_frac = max(0.0, min(1.0, float(frac)))
        try:
            self.pbar.place_configure(relx=0, relwidth=max(0.02, self._prog_frac))
        except Exception:
            pass

    def _progress_hide(self):
        self._prog_run = False
        try:
            self.pbar.place_configure(relx=0, relwidth=0)
        except Exception:
            pass

    def _animate(self):
        if not getattr(self, "_prog_run", False):
            return
        try:
            if self._prog_mode == "ind":
                self._prog_pos += self._prog_dir * 0.025
                if self._prog_pos >= 1.0:
                    self._prog_pos, self._prog_dir = 1.0, -1
                elif self._prog_pos <= 0.0:
                    self._prog_pos, self._prog_dir = 0.0, 1
                width = 0.28
                self.pbar.place_configure(relx=self._prog_pos * (1 - width),
                                          relwidth=width)
            else:
                self.pbar.place_configure(relx=0, relwidth=max(0.02, self._prog_frac))
            self.root.after(40, self._animate)
        except Exception:
            pass

    def _on_mode_change(self):
        """切换精细模式时刷新剩余次数。"""
        self._refresh_quota()

    # ---------------- 检查更新 ----------------
    def _fetch_version(self):
        """向服务端要一次版本信息，失败返回 None。"""
        try:
            req = urllib.request.Request(
                self.server.rstrip("/") + "/v1/client/version",
                headers=dict(BASE_HEADERS))
            with urllib.request.urlopen(req, timeout=15) as r:
                info = json.loads(r.read().decode("utf-8"))
            return info if isinstance(info, dict) else None
        except Exception:
            return None

    def _check_update(self, manual=False):
        """查一次服务端公布的最新版本；有新版就标红按钮，manual 时弹窗。"""
        def work():
            info = self._fetch_version()
            if info is None:
                if manual:
                    try:
                        if self.root.winfo_exists():
                            self.ui(self.set_status, "检查更新失败：连不上服务器")
                    except Exception:
                        pass
                return
            latest = (info.get("latest") or "").strip()
            newer = bool(latest) and self._is_newer(latest, VERSION)
            try:
                if self.root.winfo_exists():
                    self.ui(self._on_version_result, latest, info, newer, manual)
            except Exception:
                pass
        threading.Thread(target=work, daemon=True).start()

    def on_check_update(self):
        """点「检查更新」：手动查一次，无论有没有新版都给反馈。"""
        self.btn_check.config(state="disabled", text="检查中")
        self._check_update(manual=True)

    @staticmethod
    def _is_newer(remote, local):
        def parts(s):
            n = [int(x) for x in re.findall(r"\d+", s or "")][:3]
            while len(n) < 3:
                n.append(0)
            return n
        return parts(remote) > parts(local)

    def _on_version_result(self, latest, info, newer, manual):
        self.btn_check.config(state="normal", text="检查更新")
        if not newer:
            if manual:
                self.set_status("已是最新版本（%s）" % VERSION)
                messagebox.showinfo("检查更新",
                                    "当前已是最新版本。\n\n版本：%s" % VERSION,
                                    parent=self.root)
            return
        self.update_info = (latest, info)
        self.btn_check.config(text="有新版本", fg="#e0b64d")
        self.set_status("发现新版本 %s，点右上角「有新版本」查看更新内容" % latest)
        if manual:
            self.show_update_dialog()

    def show_update_dialog(self):
        """弹窗列出更新内容 + 下载入口。"""
        latest, info = (self.update_info or (None, {}))
        if not latest:
            return
        info = info or {}
        win = tk.Toplevel(self.root)
        win.title("发现新版本 %s" % latest)
        win.configure(bg=BG)
        win.transient(self.root)
        win.resizable(False, False)
        try:
            self.root.update_idletasks()
            x = self.root.winfo_rootx() + (self.root.winfo_width() - 440) // 2
            y = self.root.winfo_rooty() + 90
            win.geometry("440x400+%d+%d" % (max(0, x), max(0, y)))
        except Exception:
            win.geometry("440x400")
        try:
            win.grab_set()
        except Exception:
            pass

        tk.Label(win, text="发现新版本 %s" % latest, bg=BG, fg="#e0b64d",
                 font=("Microsoft YaHei", 12, "bold")).pack(pady=(18, 2))
        tk.Label(win, text="当前版本 %s%s" % (
            VERSION, "　·　发布于 %s" % info["released"] if info.get("released") else ""),
            bg=BG, fg=DIM, font=("Microsoft YaHei", 9)).pack()

        body = tk.Frame(win, bg=PANEL)
        body.pack(fill="both", expand=True, padx=18, pady=(12, 6))
        txt = tk.Text(body, bg=PANEL, fg=FG, relief="flat", bd=0, wrap="word",
                      font=("Microsoft YaHei", 9.5), highlightthickness=0,
                      padx=12, pady=10)
        txt.pack(fill="both", expand=True, side="left")
        bar = tk.Scrollbar(body, command=txt.yview)
        bar.pack(side="right", fill="y")
        txt.config(yscrollcommand=bar.set)

        lines = ["更新内容", ""]
        changes = info.get("changes") or []
        if changes:
            lines += ["· " + str(c) for c in changes]
        elif (info.get("notes") or "").strip():
            lines.append(str(info["notes"]).strip())
        else:
            lines.append("（服务端未提供更新说明）")
        lines += ["", "升级方法：下载新版压缩包，解压后覆盖到本文件夹即可。",
                  "client_config.json 会自动保留，无需重新配置。"]
        txt.insert("1.0", "\n".join(lines))
        txt.config(state="disabled")

        row = tk.Frame(win, bg=BG)
        row.pack(pady=(2, 16))
        url = (info.get("url") or "").strip()
        if url:
            tk.Button(row, text="打开下载页", command=lambda: self.on_update(url),
                      relief="flat", bd=0, bg=ACCENT, fg="#ffffff",
                      activebackground="#1e4fd0", activeforeground="#ffffff",
                      font=("Microsoft YaHei", 10), padx=20, pady=6,
                      cursor="hand2").pack(side="left", padx=6)
        tk.Button(row, text="稍后再说", command=win.destroy,
                  relief="flat", bd=0, bg="#252b34", fg="#c8ced9",
                  activebackground="#2f3742", activeforeground="#ffffff",
                  font=("Microsoft YaHei", 10), padx=20, pady=6,
                  cursor="hand2").pack(side="left", padx=6)

    def on_update(self, url=None):
        """打开下载页；没有地址就提示手动下载。"""
        if url is None:
            url = ((self.update_info or (None, {}))[1] or {}).get("url") or ""
        url = (url or "").strip()
        if url:
            try:
                import webbrowser
                webbrowser.open(url)
                self.set_status("已打开下载页面，下载后解压覆盖到本文件夹即可。")
                return
            except Exception:
                pass
        self.set_status("请到发布页下载新版客户端，解压后覆盖到本文件夹即可"
                        "（client_config.json 会自动保留，不用重新配置）")

    def current_mode(self):
        v = getattr(self, "qwen_var", None)
        return "qwen" if (v is not None and v.get()) else "fast"

    # ---------------- 小工具 ----------------
    def on_reconnect(self):
        """手动重新连接：立刻探活一次（不用等 30 秒的自动轮询）。"""
        self.online = None
        self.dot.config(fg="#e0b64d")
        self.conn.config(text="正在重新连接…", fg=DIM)
        self.btn_reconnect.config(state="disabled", text="连接中")
        self._refresh_buttons()

        def done(ok):
            self.btn_reconnect.config(state="normal", text="重新连接")
        self._probe_now(done)

    def _probe_now(self, on_done=None):
        """在后台探活一次，回来后更新状态灯与额度。

        云端隧道首次响应可能要十几秒，所以超时给到 25 秒。
        """
        def check():
            ok = False
            quotas = None
            try:
                req = urllib.request.Request(self.server.rstrip("/") + "/v1/health",
                                             headers=dict(BASE_HEADERS))
                with urllib.request.urlopen(req, timeout=25) as r:
                    h = json.loads(r.read().decode("utf-8"))
                    ok = h.get("status") == "ok"
                    quotas = h
            except Exception:
                ok = False
            try:
                if self.root.winfo_exists():
                    if quotas:
                        self.ui(self._apply_quotas, quotas)
                    self.ui(self._set_online, ok)
                    if ok:
                        self._refresh_quota()
                        self._check_update()      # 顺便看看有没有新版本
                    if on_done is not None:
                        self.ui(on_done, ok)
            except Exception:
                pass
        threading.Thread(target=check, daemon=True).start()

    def _apply_quotas(self, h):
        """记下服务端公布的额度，登录框等处显示真实数字。"""
        try:
            self.quotas = {
                "guest": int(h.get("guest_quota", 10)),
                "user": int(h.get("user_daily_quota", 30)),
                "guest_qwen": int(h.get("guest_qwen_quota", 1)),
                "user_qwen": int(h.get("user_qwen_daily_quota", 5)),
            }
        except Exception:
            pass

    def _probe_done(self, ok):
        self._probing = False

    def _poll_server(self):
        """每 30 秒自动探活一次；上一轮没返回就跳过这一轮。"""
        if not self._probing:
            self._probing = True
            self._probe_now(self._probe_done)
        try:
            self.root.after(30000, self._poll_server)
        except Exception:
            pass

    def _set_online(self, ok):
        self.online = ok
        if ok:
            self.dot.config(fg="#3ddc84")
            self.conn.config(text="已连接云端 AI", fg=FG)
        else:
            self.dot.config(fg="#ff5c5c")
            self.conn.config(text="未连接到云端服务（仍可尝试生成）", fg="#ff8a8a")
        self._refresh_buttons()

    def _refresh_buttons(self):
        # 连接状态未知（None）时也允许点——用户不用干等探活结果；
        # 只有明确探测失败（False）才禁用。
        can = bool(self.files) and not self.busy and self.online is not False
        ident = self.identity or {}
        if ident.get("kind") == "guest" and ident.get("blocked"):
            can = False                      # 访客普通额度用完，先登录
        # 选了精细模式但额度用完 -> 也不让点
        if self.current_mode() == "qwen":
            if ident.get("kind") == "user" and not ident.get("is_admin") \
                    and ident.get("qwen_remain", 0) <= 0:
                can = False
            if ident.get("kind") == "guest" and ident.get("qwen_remain", 0) <= 0:
                can = False
        self.btn_go.config(state="normal" if can else "disabled")

    # ---------------- 身份与额度 ----------------
    def on_auth(self):
        if self.token:                       # 已登录 -> 退出
            self.token = ""
            self.cfg.pop("token", None)
            save_config(self.cfg)
            self.identity = None
            self.set_status("已退出登录，回到访客模式")
            self._refresh_quota()
            return
        AuthDialog(self.root, self.server, self._on_auth_ok, self.quotas)

    def _on_auth_ok(self, token, username):
        self.token = token
        self.cfg["token"] = token
        save_config(self.cfg)
        self.set_status("已登录：%s" % username)
        self._refresh_quota()

    def _refresh_quota(self):
        """拉 /v1/me，更新身份与剩余次数。"""
        def work():
            try:
                req = urllib.request.Request(self.server.rstrip("/") + "/v1/me",
                                             headers=dict(BASE_HEADERS))
                if self.token:
                    req.add_header("X-Auth-Token", self.token)
                with urllib.request.urlopen(req, timeout=25) as r:
                    me = json.loads(r.read().decode("utf-8"))
            except Exception:
                me = None
            try:
                if self.root.winfo_exists():
                    self.ui(self._apply_quota, me)
            except Exception:
                pass
        threading.Thread(target=work, daemon=True).start()

    def _apply_quota(self, me):
        self.identity = me
        if not me:
            self.quota_label.config(text="")
            self.btn_auth.config(text="登录 / 注册")
            self.chk_qwen.config(state="normal")
            self._refresh_buttons()
            return
        kind = me.get("kind")
        # 精细模式是否可用：服务端开启 + 该身份还有额度
        qwen_on = bool(me.get("qwen_enabled", True))
        if kind == "user":
            q_rem = me.get("qwen_remain", 0)
            if me.get("is_admin"):
                txt = ("管理员：%s　普通不限次数　精细模式不限次数" % me.get("username"))
                fg = "#e0b64d"
            else:
                txt = ("已登录：%s　普通剩余 %s/%s　精细剩余 %s/%s"
                       % (me.get("username"), me.get("remain_today"), me.get("daily_quota"),
                          q_rem, me.get("qwen_quota")))
                fg = "#7fd39b"
            self.quota_label.config(text=txt, fg=fg)
            self.btn_auth.config(text="退出登录")
            qwen_on = qwen_on and (me.get("is_admin") or q_rem > 0)
        elif kind == "admin":
            self.quota_label.config(text="管理员模式（不限次数）", fg="#e0b64d")
            self.btn_auth.config(text="登录 / 注册")
        else:
            quota = me.get("guest_quota", self.quotas.get("guest", 10))
            q_rem = me.get("qwen_remain", 0)
            u_q = self.quotas.get("user", 30)
            u_qw = self.quotas.get("user_qwen", 5)
            if me.get("blocked"):
                self.quota_label.config(
                    text="访客普通次数已用完（共 %s 次）—— 点右上角「登录 / 注册」，之后每天 %d 次"
                         % (quota, u_q), fg="#ff8a8a")
            else:
                self.quota_label.config(
                    text="访客：普通剩余 %s/%s　精细剩余 %s 次　（登录后每天 %d 次 / 精细 %d 次）"
                         % (me.get("remain_today"), quota, q_rem, u_q, u_qw),
                    fg="#9aa3b2")
            self.btn_auth.config(text="登录 / 注册")
            qwen_on = qwen_on and q_rem > 0
        # 精细模式不可用时置灰并取消勾选
        if qwen_on:
            self.chk_qwen.config(state="normal", fg="#9aa3b2")
        else:
            self.qwen_var.set(False)
            self.chk_qwen.config(state="disabled", fg="#5b6472")
        self._refresh_buttons()

    def set_status(self, text):
        self.status.config(text=text)

    def ui(self, fn, *args):
        self.root.after(0, lambda: fn(*args))


class AuthDialog(object):
    """登录 / 注册对话框。"""

    def __init__(self, parent, server, on_success, quotas=None):
        self.server = (server or "").rstrip("/")
        self.on_success = on_success
        q = quotas or {}
        q_user = q.get("user", 30)
        q_guest = q.get("guest", 10)
        q_uq = q.get("user_qwen", 5)

        win = tk.Toplevel(parent)
        self.win = win
        win.title("登录 / 注册")
        win.configure(bg=BG)
        win.resizable(False, False)
        win.transient(parent)
        try:
            parent.update_idletasks()
            x = parent.winfo_rootx() + (parent.winfo_width() - 360) // 2
            y = parent.winfo_rooty() + 110
            win.geometry("360x310+%d+%d" % (max(0, x), max(0, y)))
        except Exception:
            win.geometry("360x310")
        try:
            win.grab_set()
        except Exception:
            pass

        tk.Label(win, text="登录后每天可用 %d 次" % q_user, bg=BG, fg=FG,
                 font=("Microsoft YaHei", 11, "bold")).pack(pady=(22, 4))
        tk.Label(win, text="不登录按访客计，累计 %d 次（精细模式另有 %d 次/天）"
                          % (q_guest, q_uq), bg=BG, fg=DIM,
                 font=("Microsoft YaHei", 9)).pack()

        body = tk.Frame(win, bg=BG)
        body.pack(pady=16, padx=26, fill="x")
        tk.Label(body, text="用户名", bg=BG, fg=DIM,
                 font=("Microsoft YaHei", 9)).grid(row=0, column=0, sticky="w", pady=4)
        self.user = tk.Entry(body, bg=PANEL, fg=FG, relief="flat", insertbackground=FG,
                             font=("Consolas", 10), highlightthickness=1,
                             highlightbackground=BORDER, highlightcolor=ACCENT)
        self.user.grid(row=0, column=1, sticky="ew", pady=4, padx=(8, 0))
        tk.Label(body, text="密码", bg=BG, fg=DIM,
                 font=("Microsoft YaHei", 9)).grid(row=1, column=0, sticky="w", pady=4)
        self.pwd = tk.Entry(body, show="●", bg=PANEL, fg=FG, relief="flat",
                            insertbackground=FG, font=("Consolas", 10),
                            highlightthickness=1, highlightbackground=BORDER,
                            highlightcolor=ACCENT)
        self.pwd.grid(row=1, column=1, sticky="ew", pady=4, padx=(8, 0))
        body.columnconfigure(1, weight=1)

        row = tk.Frame(win, bg=BG)
        row.pack()
        self.btn_login = tk.Button(row, text="登录", command=lambda: self.submit("login"),
                                   relief="flat", bd=0, bg=ACCENT, fg="#ffffff",
                                   activebackground="#1e4fd0", activeforeground="#ffffff",
                                   font=("Microsoft YaHei", 10), padx=22, pady=6,
                                   cursor="hand2")
        self.btn_login.pack(side="left", padx=(0, 10))
        self.btn_reg = tk.Button(row, text="注册新账号", command=lambda: self.submit("register"),
                                 relief="flat", bd=0, bg="#252b34", fg="#c8ced9",
                                 activebackground="#2f3742", activeforeground="#ffffff",
                                 font=("Microsoft YaHei", 10), padx=22, pady=6,
                                 cursor="hand2")
        self.btn_reg.pack(side="left")

        self.tip = tk.Label(win, text="", bg=BG, fg="#ff8a8a",
                            font=("Microsoft YaHei", 9), wraplength=310, justify="left")
        self.tip.pack(pady=(8, 0))
        self.pwd.bind("<Return>", lambda e: self.submit("login"))
        self.user.focus_set()

    def _post(self, path, payload):
        headers = {"Content-Type": "application/json"}
        headers.update(BASE_HEADERS)
        req = urllib.request.Request(self.server + path, method="POST",
                                     data=json.dumps(payload).encode("utf-8"),
                                     headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                return json.loads(r.read().decode("utf-8")), None
        except urllib.error.HTTPError as e:
            try:
                return None, json.loads(e.read().decode("utf-8")).get("detail", "失败")
            except Exception:
                return None, "HTTP %s" % e.code
        except Exception as e:
            return None, "无法连接服务器：%s" % e

    def submit(self, mode):
        username = self.user.get().strip()
        password = self.pwd.get()
        if not username or not password:
            self.tip.config(text="请填写用户名和密码", fg="#ff8a8a")
            return
        self.btn_login.config(state="disabled")
        self.btn_reg.config(state="disabled")
        self.tip.config(text="处理中…", fg=DIM)

        def work():
            data, err = self._post("/v1/login" if mode == "login" else "/v1/register",
                                   {"username": username, "password": password})
            try:
                self.win.after(0, lambda: self._done(data, err, username))
            except Exception:
                pass
        threading.Thread(target=work, daemon=True).start()

    def _done(self, data, err, username):
        if err or not data:
            self.tip.config(text=err or "失败", fg="#ff8a8a")
            self.btn_login.config(state="normal")
            self.btn_reg.config(state="normal")
            return
        self.on_success(data["token"], data.get("username", username))
        try:
            self.win.destroy()
        except Exception:
            pass


def _fatal(msg, detail=""):
    """启动失败时留下可读的错误信息 —— 绝不让窗口一闪就消失。"""
    text = "%s\n\n%s" % (msg, detail)
    try:
        with open(os.path.join(BASE_DIR, "_错误日志.txt"), "a",
                  encoding="utf-8") as f:
            f.write("\n[%s] %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), text))
    except Exception:
        pass
    try:
        print(text, flush=True)
    except Exception:
        pass
    try:
        r = tk.Tk()
        r.withdraw()
        messagebox.showerror("%s 启动失败" % APP_NAME,
                             text + "\n\n详情已写入 _错误日志.txt")
        r.destroy()
    except Exception:
        try:
            input("启动失败，按回车键关闭…")
        except Exception:
            time.sleep(10)


def _main(root=None):
    """root 为 None 时自己建窗口；由启动器传入时复用它已有的窗口。"""
    if sys.platform.startswith("win"):
        try:                                                # 高分屏清晰
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    own = root is None
    if own:
        root = tk.Tk()
    App(root)
    if not own:
        return 0
    if "--selftest" in sys.argv:                            # 供自动化检查界面能否构建
        root.after(400, root.destroy)
        root.mainloop()
        print("SELFTEST OK: 界面构建成功，作者=%s 版本=%s 文件=%s"
              % (AUTHOR, VERSION, os.path.basename(__file__)))
        return 0
    root.mainloop()
    return 0


def main(root=None):
    """统一入口：任何异常都不静默退出，写日志并弹窗告知。"""
    try:
        return _main(root)
    except Exception:
        import traceback
        _fatal("程序启动失败", traceback.format_exc()[-1600:])
        return 1


if __name__ == "__main__":
    if _ensure_bundled_python():
        sys.exit(0)
    sys.exit(main())
