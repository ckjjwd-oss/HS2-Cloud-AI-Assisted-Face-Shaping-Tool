# -*- coding: utf-8 -*-
"""FDE 捏脸助手 —— 一键启动器

作者：ckjj
版本：1.2.0

双击「启动.bat」后由它负责：
    1) 自动在后台拉起云端 AI 服务（本机进程，不需要联网、不需要外部 API）
    2) 等服务就绪后直接进入主界面
    3) 退出软件时自动关闭服务进程

如果 client_config.json 里配置的是**远程**服务器地址，则不会启动本地服务，
直接连远程。

直接双击本 .py 也能用：会自动切到随包的 python\\ 重新启动。
"""
import json
import os
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import tkinter as tk

APP_NAME = "FDE 捏脸助手"
AUTHOR = "ckjj"
VERSION = "1.2.0"

BASE = os.path.dirname(os.path.abspath(__file__))
SERVER_DIR = os.path.join(BASE, "服务端")
CONFIG_PATH = os.path.join(BASE, "client_config.json")
CREATE_NO_WINDOW = 0x08000000

# 便携版 Python 用的是 ._pth 隔离模式，sys.path 里不一定有本目录，
# 这里显式补上，保证 launcher 能 import 同目录的 desktop_client。
if BASE not in sys.path:
    sys.path.insert(0, BASE)


def _ensure_bundled_python():
    """双击 .py 时若用的是系统 Python，就改用随包的 python\\ 重新启动自己。"""
    if os.environ.get("FDE_RELAUNCHED"):
        return False
    exe = os.path.join(BASE, "python", "pythonw.exe")
    if not os.path.exists(exe):
        exe = os.path.join(BASE, "python", "python.exe")
    if not os.path.exists(exe):
        return False
    try:
        cur = os.path.normcase(os.path.abspath(sys.executable))
        pydir = os.path.normcase(os.path.abspath(os.path.join(BASE, "python")))
        if os.path.dirname(cur) == pydir:
            return False                   # 已经跑在随包 Python 上
    except Exception:
        return False
    try:
        env = dict(os.environ)
        env["FDE_RELAUNCHED"] = "1"
        flags = CREATE_NO_WINDOW if os.name == "nt" else 0
        subprocess.Popen([exe, os.path.abspath(__file__)] + sys.argv[1:],
                         cwd=BASE, env=env, creationflags=flags, close_fds=True)
        return True
    except Exception:
        return False

BG = "#14161a"
FG = "#e6e8ec"
DIM = "#8b93a1"
ACCENT = "#2f6bff"


# --------------------------------------------------------------------- 小工具
# 默认云端地址：配置丢失或被升级包覆盖时自动回到这里，用户无需重新配置
DEFAULT_SERVER = "https://api.xinglan.space"
LOCAL_SERVERS = ("http://127.0.0.1:8000", "http://127.0.0.1:8001",
                 "http://localhost:8000")


def load_config():
    try:
        # utf-8-sig：兼容记事本等编辑器写入的 BOM
        with open(CONFIG_PATH, encoding="utf-8-sig") as f:
            cfg = json.load(f)
        cfg = cfg if isinstance(cfg, dict) else {}
    except Exception:
        cfg = {}
    # 自愈：空配置 -> 云端；指向本机但本机没服务在跑 -> 也回云端
    srv = (cfg.get("server") or "").strip()
    if not srv:
        cfg["server"] = DEFAULT_SERVER
        save_config(cfg)
    elif srv in LOCAL_SERVERS and not health_ok(srv, timeout=0.6):
        cfg["server"] = DEFAULT_SERVER
        save_config(cfg)
    return cfg


def save_config(cfg):
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def is_remote(url):
    u = (url or "").lower()
    return bool(u) and not any(h in u for h in ("127.0.0.1", "localhost", "0.0.0.0"))


# Cloudflare 的浏览器完整性检查会拦掉 Python 默认 UA（403 / code 1010），
# 所以连远程服务器时必须带浏览器风格的 UA。
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) FDE-Client/1.0.0"


def health_ok(url, timeout=1.5):
    try:
        req = urllib.request.Request(url.rstrip("/") + "/v1/health",
                                     headers={"User-Agent": UA, "Accept": "*/*"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8")).get("status") == "ok"
    except Exception:
        return False


def port_free(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def pick_port(start=8000, tries=12):
    for p in range(start, start + tries):
        if port_free(p):
            return p
    raise RuntimeError("找不到可用端口（%d~%d 都被占用）" % (start, start + tries - 1))


def python_exe():
    """优先用随包的便携 Python，其次用当前解释器。"""
    for name in ("python.exe", "pythonw.exe"):
        p = os.path.join(BASE, "python", name)
        if os.path.exists(p):
            return p
    return sys.executable


# --------------------------------------------------------------------- 启动窗
class Splash(object):
    def __init__(self, root):
        self.root = root
        root.title("%s  v%s" % (APP_NAME, VERSION))
        root.configure(bg=BG)
        root.resizable(False, False)
        w, h = 380, 150
        sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
        root.geometry("%dx%d+%d+%d" % (w, h, (sw - w) // 2, (sh - h) // 3))

        tk.Label(root, text=APP_NAME, bg=BG, fg=FG,
                 font=("Microsoft YaHei", 13, "bold")).pack(pady=(26, 4))
        self.tip = tk.Label(root, text="正在启动…", bg=BG, fg=DIM,
                            font=("Microsoft YaHei", 9))
        self.tip.pack()
        self.bar = tk.Label(root, text="", bg=BG, fg=ACCENT,
                            font=("Microsoft YaHei", 8))
        self.bar.pack(pady=(10, 0))
        tk.Label(root, text="作者：%s　　版本：%s" % (AUTHOR, VERSION),
                 bg=BG, fg="#4a5361", font=("Microsoft YaHei", 8)).pack(side="bottom", pady=8)

    def tip_text(self, text):
        self.root.after(0, lambda: self.tip.config(text=text))

    def progress(self, text):
        self.root.after(0, lambda: self.bar.config(text=text))


def start_server(port):
    """在后台拉起服务端进程；日志写到 服务端\\_client_server.log 便于排查。"""
    py = python_exe()
    creation = CREATE_NO_WINDOW if os.name == "nt" else 0
    log = None
    try:
        os.makedirs(SERVER_DIR, exist_ok=True)
        log = open(os.path.join(SERVER_DIR, "_client_server.log"), "a",
                   encoding="utf-8", errors="replace")
    except Exception:
        log = subprocess.DEVNULL
    return subprocess.Popen(
        [py, "-m", "uvicorn", "app:app",
         "--host", "127.0.0.1", "--port", str(port),
         "--workers", "1", "--log-level", "warning"],
        cwd=SERVER_DIR, stdout=log, stderr=subprocess.STDOUT,
        creationflags=creation)


def boot(splash, state):
    """后台线程：确定服务器地址后**立刻**进界面，绝不在启动页死等。"""
    def enter():
        splash.root.after(0, lambda: finish(splash, state))

    try:
        url = (load_config().get("server") or "").strip()

        # 1) 配置里是远程地址 -> 直接进界面，连接状态由主界面异步探测
        #    （云端隧道首次响应可能要十几秒，不能在这里死等）
        if is_remote(url):
            state["url"] = url
            enter()
            return

        # 2) 本机已有服务在跑 -> 复用（快速探一下，最多约 2 秒）
        for p in (8000, 8001, 8002):
            if health_ok("http://127.0.0.1:%d" % p, timeout=1.0):
                url = "http://127.0.0.1:%d" % p
                state["url"] = url
                cfg = load_config()          # 合并写入，别冲掉登录 token
                cfg["server"] = url
                save_config(cfg)
                enter()
                return

        # 3) 本机没有服务端程序（发给用户的客户端包）-> 直接用配置里的地址进界面
        if not os.path.isdir(SERVER_DIR):
            state["url"] = url or "http://127.0.0.1:8000"
            enter()
            return

        # 4) 后台拉起本机服务，但**不等它加载完**，立刻进界面；
        #    模型加载进度由主界面左上角的连接状态反映，用户也可以点「重新连接」
        port = pick_port()
        state["proc"] = start_server(port)
        url = "http://127.0.0.1:%d" % port
        state["url"] = url
        cfg = load_config()
        cfg["server"] = url
        save_config(cfg)
        enter()
    except Exception as exc:
        # 出任何问题也不能卡在启动页，带着错误进界面由用户决定
        state["error"] = str(exc)
        state["url"] = state.get("url") or (load_config().get("server")
                                            or "http://127.0.0.1:8000")
        enter()


def finish(splash, state):
    """就绪：切换到主界面。任何异常都提示出来，不留白屏。"""
    try:
        if BASE not in sys.path:
            sys.path.insert(0, BASE)
        from desktop_client import App
        root = splash.root
        for w in root.winfo_children():
            w.destroy()
        root.resizable(True, True)
        root.geometry("580x800")
        root.minsize(540, 740)
        App(root)
        state["ui"] = True
    except Exception:
        import traceback
        import tkinter.messagebox as mb
        detail = traceback.format_exc()[-1200:]
        state["error"] = "主界面启动失败: " + detail.strip().splitlines()[-1]
        try:
            with open(os.path.join(BASE, "_错误日志.txt"), "a",
                      encoding="utf-8") as f:
                f.write("\n[%s] 主界面启动失败\n%s\n"
                        % (time.strftime("%Y-%m-%d %H:%M:%S"), detail))
        except Exception:
            pass
        mb.showerror(APP_NAME, "主界面启动失败：\n\n%s" % detail[-600:])
        try:
            splash.root.destroy()
        except Exception:
            pass


def fail(splash, state):
    import tkinter.messagebox as mb
    mb.showerror(APP_NAME, str(state.get("error") or "启动失败"))
    splash.root.destroy()


def _fatal(detail):
    """启动器自身出错时：写日志 + 弹窗，绝不闪退。"""
    try:
        with open(os.path.join(BASE, "_错误日志.txt"), "a",
                  encoding="utf-8") as f:
            f.write("\n[%s] 启动器失败\n%s\n"
                    % (time.strftime("%Y-%m-%d %H:%M:%S"), detail))
    except Exception:
        pass
    try:
        print(detail, flush=True)
    except Exception:
        pass
    try:
        import tkinter.messagebox as mb
        r = tk.Tk()
        r.withdraw()
        mb.showerror(APP_NAME + " 启动失败",
                     "启动器出错，详情已写入 _错误日志.txt\n\n" + detail[-700:])
        r.destroy()
    except Exception:
        try:
            input("启动失败，按回车键关闭…")
        except Exception:
            time.sleep(10)


def main():
    try:
        return _main()
    except Exception:
        import traceback
        _fatal(traceback.format_exc()[-1600:])
        return 1


def _main():
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass

    root = tk.Tk()
    splash = Splash(root)
    state = {"proc": None, "url": None, "error": None, "ui": False}
    threading.Thread(target=boot, args=(splash, state), daemon=True).start()

    if "--selftest" in sys.argv:
        # 自动化检查：等主界面真正建起来（或超时）后打印结果并退出
        def watch():
            for _ in range(240):                    # 最多 120 秒
                if state.get("ui") or state.get("error"):
                    break
                time.sleep(0.5)
            ok = bool(state.get("ui"))
            print("SELFTEST %s ui=%s url=%s %s"
                  % ("OK" if ok else "FAIL", ok, state.get("url"),
                     state.get("error") or ""), flush=True)
            root.after(0, root.destroy)
        threading.Thread(target=watch, daemon=True).start()

    try:
        root.mainloop()
    finally:
        proc = state.get("proc")
        if proc is not None and proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=8)
            except Exception:
                proc.kill()
    return 0


if __name__ == "__main__":
    if _ensure_bundled_python():
        sys.exit(0)
    sys.exit(main())
